// This example limits Zip Code inputs to 5 numeric characters
jQuery(function($){
   $("input#zip").mask("99999");
});